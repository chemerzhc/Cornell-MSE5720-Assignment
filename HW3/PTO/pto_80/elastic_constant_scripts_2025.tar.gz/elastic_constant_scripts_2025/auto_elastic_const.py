# Updated by Sabrina Li sjl57@cornell, Tucker Swenson tjs367@cornell.edu
# Mar 2023, Aug 2025
# Purpose: run jobs to calculate bulk modulus, C11, C12, and C44 elastic constants (strain matrices coded for cubic cells)

# Import necessary modules and functions
import numpy as np
import os
from create_sh_file import create_sh_file

# Print extra information about the script operations if set to True (default is False)
VERBOSE = False

# Set the minimum and maximum values of the strain amplitude, as well as the increment
ETA_MIN_VALUE = -0.006
ETA_MAX_VALUE = 0.006
ETA_INCREMENT = 0.002

BASE_DIRECTORY = "./" # Edit if you're not running this script from within the folder that contains create_sh_file.py

# Only change CELL_VALUE if you change "CELL PARAMETER alat" to "CELL PARAMETER angstrom"  
CELL_VALUE = 0.5 # For cubic Si, 0.5 is already correct. This value will be multiplied by the lattice parameter which is read through celldm(1)

# Other cell value variables for use in cells other than cubic cells:
# CELL_VALUE_B = # Only set this variable if you use "CELL PARAMETER angstrom" and have an orthorhombic cell
# CELL_VALUE_C = # Only set this variable if you use "CELL PARAMETER angstrom" and have an orthorhombic or tetragonal cell

# Define the lattice vectors in a matrix (lattice vectors are row vectors)
# See the pw.x input file description of the "ibrav" flag for appropriate examples of cell matrix definitions.
CELL_PARAMETER = np.matrix([[0, CELL_VALUE, CELL_VALUE ], [CELL_VALUE , 0, CELL_VALUE ], [ CELL_VALUE, CELL_VALUE, 0 ]])

# Examples of primitive cell matrices for cells other than cubic cells:
# CELL_PARAMETER = np.matrix([[CELL_VALUE, 0, 0], [0, CELL_VALUE_B, 0], [0, 0, CELL_VALUE_C]]) # Example primitive tetragonal cell matrix
# CELL_PARAMETER = np.matrix([[CELL_VALUE, 0, 0], [0, CELL_VALUE, 0], [0, 0, CELL_VALUE_C]]]) # Example primitive orthorhombic cell matrix

def construct_Ts():
    t0 = np.zeros((3,3)) #C11+2C12 for a cubic cell
    t0[0,0] = 1
    t0[1,1] = 1
    t0[2,2] = 1

    t1 = np.zeros((3,3)) #C11-C12 for a cubic cell
    t1[0,0] = 1
    t1[1,1] = 1
    t1[2,2] = -2

    t2 = np.zeros((3,3)) #C44 for a cubic cell
    t2[0,1] = 0.5
    t2[1,0] = 0.5

    # t3 = np.zeros((3,3)) # Feel free to define additional strain matrices t3, t4, ..., as needed to compute desired elastic constants
    # t3[0,1] = Fill this in if you'd like and add the "t3" variable to the "return" statement below

    return [t0, t1, t2]
   


def run_job(T, gamma, dir_name):     # create the directory for this job run

    if BASE_DIRECTORY[-1] != '/':
        base_dir = BASE_DIRECTORY + '/' # Terminate directory string in a forward slash if one is not present

    else:
        base_dir = BASE_DIRECTORY

    directory = base_dir + dir_name + "/" # Ensure that the directory string ends in a forward slash

    if not os.path.exists(directory):
        os.makedirs(directory) # Create the directory for this strained calculation

    if VERBOSE: # Print some information if the calculation is verbose:
        print ("creating files for directory {0}\n".format(directory))
    
    matrix = np.matmul(CELL_PARAMETER, gamma*T + np.identity(3)) # Apply the strain to the cell matrix via matrix multiplication

    filename = directory + "jobscript.sh" # Write the path to the new job input file

    sh_str = create_sh_file(matrix) # Use the strained cell matrix to write a new input file

    shfile = open(filename, "w") # Open the new input file
    shfile.write(sh_str) # Write the input file text to the new file
    shfile.close() # Close the new input file


if __name__ == "__main__":
    T_list = construct_Ts() # Generate a set of strain matrixes

    gamma_list = np.around(np.arange(ETA_MIN_VALUE, ETA_MAX_VALUE + ETA_INCREMENT, ETA_INCREMENT),3) # Generate a set of strain amplitudes

    T_num = 0 # Set a counter for how many strain matrices have been applied. Used to name directories

    for T in T_list: # Cycle through the strain matrixes

        for gamma in gamma_list: # Cycle through the strain amplitudes

            if np.abs(gamma) < 10e-10: # Round a value which is very close to 0 to be 0 (fixes numerical noise)
                gamma = 0

            dir_name = "job_T{0}_gamma{1}".format(T_num, gamma) # Create a directory for the new calculation named after the strain matrix and amplitude

            run_job(T, gamma, dir_name) # Create the input files for the strained calculations

        T_num += 1 # Increment the counter
